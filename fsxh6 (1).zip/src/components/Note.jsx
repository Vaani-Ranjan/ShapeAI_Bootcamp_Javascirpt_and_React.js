import React from "react";

function Note() {
  return (
<div classname = "note">
  <h1>Javascript and React.js</h1>
Hi I made this project during the 7 Days Free Bootcamp, conducted by <b> ShapeAI </b>.
The instructor during the session was Mr. Shaurya Sinha (Data Analyst Intern at Jio). I got to learn a a lot during these 7 days and it was an amazing experience learning with SHAPEAI.
<a href="https://www.youtube.com/playlist?list=PL7zI8TDRnbulLetcbkthT0p_IzwgRAYbu">
<img src = "https://github.com/ShapeAI/PYTHON-AND-DATA-ANALYTICS/raw/main/YOUTUBE%20THUMBNAIL-4.png">
</img>
</a>
I got to have hands on experience on:
<ol>
<li> Javascript</li>
  <li> HTML</li>
    <li> React.js</li>
    </ol>
during these 7 days , and everything was explained from the very basics so that anyone with evn zero knowledge and experience can learn
I enjoyed these 7 days, uou can as well. To register for next free 7 days bootcamp, visit:
<a href= "https://www.shapeai.tech"> www.shapeai.tech </a>  
 or follow ShapeAI on:
 <ol>
   <li><a href= "https://in.linkedin.com/company/shapeai">Linkedin</a></li>
   <li><a href = "https://www.instagram.com/shape.ai/?hl=en">Instagram</a></li>
   <li><a href = "https://www.youtube.com/channel/UCTUVDLTW9meuDXWcbmISPdA">Youtube</a></li>
   <li><a href = "https://github.com/shapeal">Github</a></li>
 </ol>
</div>
    );
  }

  export default Note;